using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float strength = 4f;
    public float gravity = -9.81f;
    public float tilt = 5f;
    public int check = 0;
    private Vector3 direction;
    public int score=0;
    private void Start()
    {
      
    }

    private void OnEnable()
    {
        Vector3 position = transform.position;
        position.y = 0f;
        transform.position = position;
        direction = Vector3.zero;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            direction = Vector3.up * strength;
            check++;
        }
        if (check > 0)
        {
            direction.y += gravity * Time.deltaTime; 
        }
        transform.position += direction * Time.deltaTime;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name=="obs")
        {
            print("Game Over");
        }
        else if (other.gameObject.name == "Scoring")
        {
            score++;
            print("score: " + score);
        }
       // print("Game Over");
    }
}
